package environment;

/**
 *  A class for ClockEvents, meaning that the Clock has increased
 */
public class ClockEvent {

    /**
     *  Initializes a new ClockEvent instance
     */
    public ClockEvent() {}

}
